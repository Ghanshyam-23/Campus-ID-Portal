<?php
session_start();

// If already logged in as admin, redirect to admin dashboard
if (isset($_SESSION['admin_id'])) {
    header('Location: admin_dashboard.php');
    exit();
}

// Database connection
$host = 'localhost';
$dbname = 'campus_id_portal';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$error = '';
$debug_info = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } else {
        // Check if admin exists
        $sql = "SELECT * FROM admin_users WHERE username = :username";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        
        if ($stmt->rowCount() === 1) {
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Debug info
            $debug_info = "Stored hash: " . $admin['password'] . "<br>";
            $debug_info .= "Password provided: " . $password . "<br>";
            
            // Try both password verification methods
            $password_correct = false;
            
            // Method 1: password_verify (for hashed passwords)
            if (password_verify($password, $admin['password'])) {
                $password_correct = true;
                $debug_info .= "Authentication method: password_verify (hashed)<br>";
            } 
            // Method 2: Direct comparison (for plain text passwords)
            elseif ($password === $admin['password']) {
                $password_correct = true;
                $debug_info .= "Authentication method: direct comparison (plain text)<br>";
            }
            // Method 3: Try default password
            elseif ($password === 'admin123' && password_verify('admin123', $admin['password'])) {
                $password_correct = true;
                $debug_info .= "Authentication method: default password<br>";
            }
            
            if ($password_correct) {
                // Set admin session
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_name'] = $admin['full_name'];
                $_SESSION['user_type'] = 'admin';
                
                // Redirect to admin dashboard
                header('Location: admin_dashboard.php');
                exit();
            } else {
                $error = 'Invalid password.';
                $debug_info .= "Password verification failed.<br>";
            }
        } else {
            $error = 'No admin account found with this username.';
            // Check if admin table exists
            $table_exists = $pdo->query("SHOW TABLES LIKE 'admin_users'")->rowCount() > 0;
            $debug_info = "Admin table exists: " . ($table_exists ? 'Yes' : 'No') . "<br>";
            
            if (!$table_exists) {
                $error .= ' The admin_users table does not exist.';
            }
        }
    }
}

// If admin table doesn't exist or is empty, create default admin
$admin_count = 0;
$table_exists = $pdo->query("SHOW TABLES LIKE 'admin_users'")->rowCount() > 0;

if ($table_exists) {
    $admin_count = $pdo->query("SELECT COUNT(*) as count FROM admin_users")->fetch()['count'];
} else {
    // Create admin table
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        full_name VARCHAR(100) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
}

if ($admin_count == 0) {
    // Create default admin user
    $hashed_password = password_hash('admin123', PASSWORD_DEFAULT);
    $sql = "INSERT INTO admin_users (username, password, full_name) VALUES ('admin', '$hashed_password', 'Administrator')";
    $pdo->exec($sql);
    $debug_info .= "Default admin user created.<br>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Campus ID Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #3a0ca3, #4361ee);
            height: 100vh;
            display: flex;
            align-items: center;
        }
        .login-card {
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            background: white;
        }
        .admin-icon {
            font-size: 3rem;
            color: #3a0ca3;
        }
        .debug-info {
            font-size: 12px;
            background: #f8f9fa;
            padding: 10px;
            border-radius: 5px;
            margin-top: 15px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card login-card">
                    <div class="card-header bg-primary text-white text-center py-4">
                        <div class="admin-icon mb-2">
                            <i class="bi bi-shield-lock"></i>
                        </div>
                        <h3>Admin Login</h3>
                        <p class="mb-0">Campus ID Portal System</p>
                    </div>
                    <div class="card-body p-4">
                        <?php if ($error): ?>
                            <div class="alert alert-danger">
                                <?php echo $error; ?>
                                <br>
                                <small><a href="admin_password_reset.php">Reset admin password</a></small>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" required 
                                       value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : 'admin'; ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required 
                                       value="<?php echo isset($_POST['password']) ? htmlspecialchars($_POST['password']) : ''; ?>">
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary btn-lg">Login as Admin</button>
                            </div>
                        </form>
                        
                        <div class="text-center mt-4">
                            <div class="alert alert-info">
                                <h6>Default Admin Credentials</h6>
                                <p class="mb-1"><strong>Username:</strong> admin</p>
                                <p class="mb-0"><strong>Password:</strong> admin123</p>
                            </div>
                        </div>
                        
                        <div class="text-center">
                            <button onclick="toggleDebug()" class="btn btn-sm btn-outline-secondary">Debug Info</button>
                        </div>
                        
                        <div id="debugInfo" class="debug-info">
                            <?php echo $debug_info; ?>
                        </div>
                        
                        <hr>
                        
                        <div class="text-center">
                            <a href="admin_password_reset.php" class="btn btn-warning">Reset Admin Password</a>
                            <a href="login.php" class="btn btn-outline-secondary">Student Login</a>
                            <a href="index.php" class="btn btn-link">Back to Home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleDebug() {
            const debugInfo = document.getElementById('debugInfo');
            debugInfo.style.display = debugInfo.style.display === 'none' ? 'block' : 'none';
        }
    </script>
</body>
</html>