<?php
/**
 * phpMyAdmin Configuration Fix
 * Helps resolve the "Access denied for user 'root'@'localhost'" error
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>phpMyAdmin Fix - Campus ID Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        pre {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
        }
        .instruction {
            background: #e9ecef;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h3 class="text-center">phpMyAdmin Access Denied Fix</h3>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <h5>Understanding the Problem</h5>
                            <p>Your phpMyAdmin is trying to connect to MySQL with username 'root' and no password, but your MySQL server is expecting a password.</p>
                            <p>Error: <code>Access denied for user 'root'@'localhost' (using password: NO)</code></p>
                        </div>

                        <h4>Solution 1: Update phpMyAdmin Configuration</h4>
                        <div class="instruction">
                            <p>You need to edit the phpMyAdmin configuration file to include your MySQL root password.</p>
                            
                            <h5>Steps:</h5>
                            <ol>
                                <li>Locate your phpMyAdmin configuration file. It's usually at:
                                    <ul>
                                        <li><strong>XAMPP:</strong> <code>C:\xampp\phpMyAdmin\config.inc.php</code></li>
                                        <li><strong>WAMP:</strong> <code>C:\wamp\apps\phpmyadmin\config.inc.php</code></li>
                                        <li><strong>MAMP:</strong> <code>/Applications/MAMP/bin/phpMyAdmin/config.inc.php</code></li>
                                    </ul>
                                </li>
                                <li>Open the file in a text editor (like Notepad++ or VS Code)</li>
                                <li>Find the line that looks like:
                                    <pre>$cfg['Servers'][$i]['password'] = '';</pre>
                                </li>
                                <li>Change it to include your MySQL root password:
                                    <pre>$cfg['Servers'][$i]['password'] = 'your_password_here';</pre>
                                </li>
                                <li>Save the file and restart your web server</li>
                            </ol>
                        </div>

                        <h4>Solution 2: Reset MySQL Root Password to Blank</h4>
                        <div class="instruction">
                            <p>If you prefer to use a blank password (not recommended for production):</p>
                            
                            <h5>Using Command Line:</h5>
                            <ol>
                                <li>Open Command Prompt (Windows) or Terminal (Mac/Linux)</li>
                                <li>Navigate to your MySQL bin directory:
                                    <ul>
                                        <li><strong>XAMPP:</strong> <code>cd C:\xampp\mysql\bin</code></li>
                                        <li><strong>WAMP:</strong> <code>cd C:\wamp\bin\mysql\mysql[version]\bin</code></li>
                                        <li><strong>MAMP:</strong> <code>cd /Applications/MAMP/Library/bin/</code></li>
                                    </ul>
                                </li>
                                <li>Run this command to set a blank password:
                                    <pre>mysqladmin -u root password ""</pre>
                                </li>
                            </ol>
                        </div>

                        <h4>Solution 3: Create a new config.inc.php file</h4>
                        <div class="instruction">
                            <p>If you can't find the config.inc.php file, create a new one with this content:</p>
                            
                            <pre>&lt;?php
/* Server: localhost [1] */
$i++;
$cfg['Servers'][$i]['verbose'] = 'localhost';
$cfg['Servers'][$i]['host'] = 'localhost';
$cfg['Servers'][$i]['port'] = '3306';
$cfg['Servers'][$i]['socket'] = '';
$cfg['Servers'][$i]['connect_type'] = 'tcp';
$cfg['Servers'][$i]['extension'] = 'mysqli';
$cfg['Servers'][$i]['auth_type'] = 'config';
$cfg['Servers'][$i]['user'] = 'root';
$cfg['Servers'][$i]['password'] = 'your_password_here'; // ADD YOUR PASSWORD HERE
$cfg['Servers'][$i]['AllowNoPassword'] = false;

/* End of servers configuration */

$cfg['DefaultLang'] = 'en';
$cfg['ServerDefault'] = 1;
$cfg['UploadDir'] = '';
$cfg['SaveDir'] = '';
?&gt;</pre>
                            
                            <p>Replace <code>your_password_here</code> with your actual MySQL root password and save this as <code>config.inc.php</code> in your phpMyAdmin directory.</p>
                        </div>

                        <h4>Still having issues?</h4>
                        <div class="alert alert-warning">
                            <p>If you're still having problems, try these steps:</p>
                            <ol>
                                <li><a href="mysql_diagnostic.php">Run the MySQL Diagnostic Tool</a> to find your correct MySQL credentials</li>
                                <li><a href="test_credentials.php">Test your MySQL credentials</a> to make sure they work</li>
                                <li>Make sure your MySQL server is running</li>
                                <li>Try accessing phpMyAdmin directly at <a href="http://localhost/phpmyadmin" target="_blank">http://localhost/phpmyadmin</a></li>
                            </ol>
                        </div>

                        <div class="text-center mt-4">
                            <a href="mysql_diagnostic.php" class="btn btn-primary">Find My MySQL Credentials</a>
                            <a href="test_credentials.php" class="btn btn-secondary">Test MySQL Connection</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>