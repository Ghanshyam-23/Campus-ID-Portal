<?php
/**
 * MySQL Status Checker
 * This script helps determine if MySQL is running and accessible
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MySQL Status Check - Campus ID Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .status-box {
            padding: 20px;
            margin: 10px 0;
            border-radius: 5px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .warning {
            background-color: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">MySQL Server Status Check</h3>
                    </div>
                    <div class="card-body">
                        <h4>Checking MySQL Server Status...</h4>
                        
                        <?php
                        // Function to check if a port is open
                        function checkPort($host, $port, $timeout = 1) {
                            $connection = @fsockopen($host, $port, $errno, $errstr, $timeout);
                            if (is_resource($connection)) {
                                fclose($connection);
                                return true;
                            }
                            return false;
                        }
                        
                        // Check common MySQL ports
                        $ports = [3306, 8889];
                        $mysqlRunning = false;
                        $activePort = null;
                        
                        foreach ($ports as $port) {
                            if (checkPort('localhost', $port)) {
                                $mysqlRunning = true;
                                $activePort = $port;
                                break;
                            }
                        }
                        ?>
                        
                        <div class="status-box <?php echo $mysqlRunning ? 'success' : 'error'; ?>">
                            <h5>MySQL Server Status</h5>
                            <?php if ($mysqlRunning): ?>
                                <p>✓ MySQL server is running on port <?php echo $activePort; ?></p>
                            <?php else: ?>
                                <p>✗ MySQL server is not running or not accessible</p>
                                <p>Checked ports: 3306 (standard), 8889 (MAMP)</p>
                            <?php endif; ?>
                        </div>
                        
                        <?php if (!$mysqlRunning): ?>
                            <div class="status-box warning">
                                <h5>Next Steps</h5>
                                <p>Your MySQL server doesn't appear to be running. Here's how to start it:</p>
                                
                                <h6>For XAMPP:</h6>
                                <ol>
                                    <li>Open XAMPP Control Panel</li>
                                    <li>Start the MySQL service</li>
                                    <li>Try accessing the website again</li>
                                </ol>
                                
                                <h6>For WAMP:</h6>
                                <ol>
                                    <li>Open WAMP Server</li>
                                    <li>Wait for the icon to turn green</li>
                                    <li>If it's orange or red, click it and select "Start Services"</li>
                                </ol>
                                
                                <h6>For MAMP:</h6>
                                <ol>
                                    <li>Open MAMP</li>
                                    <li>Click "Start Servers"</li>
                                    <li>Wait for the MySQL indicator to show it's running</li>
                                </ol>
                                
                                <h6>If you don't have a server installed:</h6>
                                <p>Download and install one of these:</p>
                                <ul>
                                    <li><a href="https://www.apachefriends.org/" target="_blank">XAMPP</a> (Windows, Mac, Linux)</li>
                                    <li><a href="https://www.wampserver.com/" target="_blank">WAMP</a> (Windows)</li>
                                    <li><a href="https://www.mamp.info/" target="_blank">MAMP</a> (Mac)</li>
                                </ul>
                            </div>
                        <?php else: ?>
                            <div class="status-box success">
                                <h5>MySQL is Running</h5>
                                <p>Good! MySQL is running on port <?php echo $activePort; ?>.</p>
                                <p>Now let's check if you have the correct credentials.</p>
                                <a href="db_test.php" class="btn btn-primary">Test Database Connection</a>
                            </div>
                        <?php endif; ?>
                        
                        <div class="mt-4">
                            <h5>Common MySQL Default Credentials</h5>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Server</th>
                                        <th>Username</th>
                                        <th>Password</th>
                                        <th>Port</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>XAMPP</td>
                                        <td>root</td>
                                        <td><em>(blank/empty)</em></td>
                                        <td>3306</td>
                                    </tr>
                                    <tr>
                                        <td>WAMP</td>
                                        <td>root</td>
                                        <td><em>(blank/empty)</em></td>
                                        <td>3306</td>
                                    </tr>
                                    <tr>
                                        <td>MAMP</td>
                                        <td>root</td>
                                        <td>root</td>
                                        <td>8889</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>