<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';

$error = '';
$success = '';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid request. Please try again.";
    } else {

        $full_name = trim($_POST['full_name']);
        $university_name = trim($_POST['university_name']);
        $college_name = trim($_POST['college_name']);
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];
        $course = trim($_POST['course']);
        $dob = $_POST['dob'];
        $blood_group = $_POST['blood_group'];
        $phone = trim($_POST['phone']);
        $address = trim($_POST['address']);

        if (empty($full_name) || empty($university_name) || empty($college_name) || empty($email) || empty($password) || empty($course) || empty($dob)) {
            $error = 'Please fill in all required fields.';
        } 
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email format.';
        } 
        elseif (!empty($phone) && !preg_match('/^[0-9]{10}$/', $phone)) {
            $error = 'Phone number must be 10 digits.';
        } 
        elseif ($password !== $confirm_password) {
            $error = 'Passwords do not match.';
        } 
        elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters long.';
        } 
        else {

            try {

                $sql = "SELECT id FROM users WHERE email = :email";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':email', $email);
                $stmt->execute();

                if ($stmt->rowCount() > 0) {

                    $error = 'Email already exists.';

                } else {

                    $photo_path = null;

                    if (!empty($_FILES['photo']['name'])) {

                        $upload_result = uploadPhoto($_FILES['photo']);

                        if ($upload_result['success']) {
                            $photo_path = $upload_result['file_path'];
                        } else {
                            $error = $upload_result['message'];
                        }

                    }

                    if (empty($error)) {

                        $student_id = generateStudentId($pdo);
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                        $sql = "INSERT INTO users 
                        (student_id,password,full_name,university_name,college_name,email,course,dob,blood_group,phone,address,photo_path)
                        VALUES
                        (:student_id,:password,:full_name,:university_name,:college_name,:email,:course,:dob,:blood_group,:phone,:address,:photo_path)";

                        $stmt = $pdo->prepare($sql);

                        $stmt->bindParam(':student_id',$student_id);
                        $stmt->bindParam(':password',$hashed_password);
                        $stmt->bindParam(':full_name',$full_name);
                        $stmt->bindParam(':university_name',$university_name);
                        $stmt->bindParam(':college_name',$college_name);
                        $stmt->bindParam(':email',$email);
                        $stmt->bindParam(':course',$course);
                        $stmt->bindParam(':dob',$dob);
                        $stmt->bindParam(':blood_group',$blood_group);
                        $stmt->bindParam(':phone',$phone);
                        $stmt->bindParam(':address',$address);
                        $stmt->bindParam(':photo_path',$photo_path);

                        if ($stmt->execute()) {

                            $success = 'Registration successful! Your Student ID is: <strong>' . $student_id . '</strong>. Please wait for admin approval.';
                            $_POST = array();

                        } else {

                            $error = 'Something went wrong. Please try again.';
                        }
                    }
                }

            } catch (PDOException $e) {

                $error = "Database error: " . $e->getMessage();

            }

        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Register - Campus ID Portal</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<?php include 'includes/header.php'; ?>

<div class="container mt-5">

<div class="row justify-content-center">

<div class="col-md-8">

<div class="card shadow-lg border-0">

<div class="card-header bg-primary text-white">
<h3 class="text-center mb-0">Student Registration</h3>
</div>

<div class="card-body">

<?php if ($error): ?>
<div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if ($success): ?>
<div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">

<input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

<div class="row">

<div class="col-md-6">

<div class="mb-3">
<label class="form-label">Full Name *</label>
<input type="text" class="form-control" name="full_name" required>
</div>

<div class="mb-3">
<label class="form-label">University Name *</label>
<input type="text" class="form-control" name="university_name" required>
</div>

<div class="mb-3">
<label class="form-label">College Name *</label>
<input type="text" class="form-control" name="college_name" required>
</div>

<div class="mb-3">
<label class="form-label">Email Address *</label>
<input type="email" class="form-control" name="email" required>
</div>

<div class="mb-3">
<label class="form-label">Password *</label>
<input type="password" class="form-control" name="password" required>
</div>

<div class="mb-3">
<label class="form-label">Confirm Password *</label>
<input type="password" class="form-control" name="confirm_password" required>
</div>

<div class="mb-3">
<label class="form-label">Course / Department *</label>
<input type="text" class="form-control" name="course" required>
</div>

</div>

<div class="col-md-6">

<div class="mb-3">
<label class="form-label">Date of Birth *</label>
<input type="date" class="form-control" name="dob" required>
</div>

<div class="mb-3">
<label class="form-label">Blood Group</label>
<select class="form-select" name="blood_group">
<option value="">Select</option>
<option>A+</option>
<option>A-</option>
<option>B+</option>
<option>B-</option>
<option>AB+</option>
<option>AB-</option>
<option>O+</option>
<option>O-</option>
</select>
</div>

<div class="mb-3">
<label class="form-label">Phone</label>
<input type="tel" class="form-control" name="phone">
</div>

<div class="mb-3">
<label class="form-label">Address</label>
<textarea class="form-control" name="address"></textarea>
</div>

<div class="mb-3">
<label class="form-label">Photo</label>
<input type="file" class="form-control" name="photo">
</div>

</div>

</div>

<div class="d-grid">
<button type="submit" class="btn btn-primary">Register</button>
</div>

</form>

</div>

</div>

</div>

</div>

</div>

<?php include 'includes/footer.php'; ?>

</body>
</html>