<?php

/* Generate Unique Student ID */
function generateStudentId($pdo) {

    $year = date('Y');

    $sql = "SELECT student_id FROM users 
            WHERE student_id LIKE 'ST$year%' 
            ORDER BY student_id DESC 
            LIMIT 1";

    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $last = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($last) {

        $last_id = $last['student_id'];

        // Extract last number
        $number = substr($last_id, -4);

        $new_number = $number + 1;

    } else {

        $new_number = 1;

    }

    return 'ST' . $year . str_pad($new_number, 4, '0', STR_PAD_LEFT);
}


/* Check if Student is Logged In */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}


/* Check if Admin is Logged In */
function isAdmin() {
    return isset($_SESSION['admin_id']);
}


/* Upload Student Photo */
function uploadPhoto($file) {

    $targetDir = "../uploads/photos/";

    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    $fileName = uniqid() . '_' . basename($file["name"]);
    $targetFilePath = $targetDir . $fileName;

    $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

    /* Check if file is image */
    $check = getimagesize($file["tmp_name"]);
    if ($check === false) {
        return ["success" => false, "message" => "File is not an image."];
    }

    /* File size limit (5MB) */
    if ($file["size"] > 5000000) {
        return ["success" => false, "message" => "File is too large. Maximum size is 5MB."];
    }

    /* Allowed formats */
    $allowedTypes = ["jpg", "jpeg", "png", "gif"];

    if (!in_array($fileType, $allowedTypes)) {
        return ["success" => false, "message" => "Only JPG, JPEG, PNG & GIF files are allowed."];
    }

    /* Upload file */
    if (move_uploaded_file($file["tmp_name"], $targetFilePath)) {

        return [
            "success" => true,
            "file_path" => "uploads/photos/" . $fileName
        ];

    } else {

        return [
            "success" => false,
            "message" => "Sorry, there was an error uploading your file."
        ];

    }
}


/* Status Badge for Dashboard */
function getStatusBadge($status) {

    switch ($status) {

        case 'approved':
        case 'active':
            return '<span class="badge bg-success">' . ucfirst($status) . '</span>';

        case 'pending':
            return '<span class="badge bg-warning">' . ucfirst($status) . '</span>';

        case 'rejected':
        case 'revoked':
        case 'expired':
            return '<span class="badge bg-danger">' . ucfirst($status) . '</span>';

        default:
            return '<span class="badge bg-secondary">' . ucfirst($status) . '</span>';
    }
}


/* Redirect Function */
function redirect($url) {
    header("Location: $url");
    exit();
}


/* Sanitize User Input */
function sanitizeInput($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

?>