<footer class="bg-dark text-white py-4 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h5>Campus ID Portal</h5>
                <p>Simplifying student identification management for educational institutions.</p>
            </div>
            <div class="col-md-3">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li><a href="register.php" class="text-white">Register</a></li>
                    <li><a href="login.php" class="text-white">Login</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5>Contact</h5>
                <p>Email: admin@campusidportal.edu<br>Phone: (123) 456-7890</p>
            </div>
        </div>
        <hr>
        <p class="text-center mb-0">© 2023 Campus ID Portal. All rights reserved.</p>
    </div>
</footer>