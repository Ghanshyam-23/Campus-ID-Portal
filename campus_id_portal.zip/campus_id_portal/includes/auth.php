<?php
// Authentication functions

function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        redirect('login.php');
    }
}

function requireAdmin() {
    if (!isAdmin()) {
        redirect('../login.php');
    }
}

function checkUserStatus() {
    global $pdo;
    
    if (isLoggedIn()) {
        $user_id = $_SESSION['user_id'];
        $sql = "SELECT status FROM users WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id', $user_id);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && $user['status'] !== 'approved') {
            session_unset();
            session_destroy();
            redirect('login.php?message=Your account has been ' . $user['status']);
        }
    }
}
?>