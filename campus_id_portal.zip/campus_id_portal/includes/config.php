<?php
// Database configuration for XAMPP (default settings)
$host = 'localhost';
$dbname = 'campus_id_portal';
$username = 'root';
$password = ''; // Empty password for XAMPP default

// Attempt to connect to MySQL database
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed. Please check your MySQL server is running and credentials are correct.");
}

// Set timezone
date_default_timezone_set('UTC');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Define base URL
$base_url = 'http://' . $_SERVER['HTTP_HOST'] . '/campus_id_portal/';
define('BASE_URL', $base_url);

// Include functions
require_once 'functions.php';
?>