<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isLoggedIn() && !isset($_GET['id'])) {
    header('Location: login.php');
    exit();
}

if (isset($_GET['id'])) {
    $id_card_id = $_GET['id'];
    $sql = "SELECT ic.*, u.* FROM id_cards ic 
            JOIN users u ON ic.user_id = u.id 
            WHERE ic.id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $id_card_id, PDO::PARAM_INT);
    $stmt->execute();
    $id_data = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT ic.*, u.* FROM id_cards ic 
            JOIN users u ON ic.user_id = u.id 
            WHERE ic.user_id = :user_id AND ic.status = 'active'";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $id_data = $stmt->fetch(PDO::FETCH_ASSOC);
}

if (!$id_data) {
    die("ID card not found or inactive.");
}

$university_name = !empty($id_data['university_name']) ? $id_data['university_name'] : "University Campus";

// PHOTO PATH: force specific image
$photo_path = "uploads/d75165c0-bfd8-4c71-b8d3-4909dd183107.jpg";

if (!file_exists($photo_path)) {
    $photo_path = "assets/img/default-avatar.png";
}

$valid_until = !empty($id_data['valid_until']) ? date('m/d/Y', strtotime($id_data['valid_until'])) : '07/21/2027';
$issued_on = !empty($id_data['issued_on']) ? date('m/d/Y', strtotime($id_data['issued_on'])) : date('m/d/Y');

$dob = !empty($id_data['dob']) ? date('m/d/Y', strtotime($id_data['dob'])) : '03/08/2006';
$blood_group = !empty($id_data['blood_group']) ? $id_data['blood_group'] : 'A+';
$student_id = !empty($id_data['student_id']) ? $id_data['student_id'] : 'ST20250001';
$course = !empty($id_data['course']) ? $id_data['course'] : 'CS';
$full_name = !empty($id_data['full_name']) ? $id_data['full_name'] : 'Ghanshyam Sapkal';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ID Card</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: #f4f4f4;
        }
        .id-card {
            width: 350px;
            height: 500px;
            border: 2px solid #000;
            border-radius: 15px;
            overflow: hidden;
            background: #fff;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.3);
            position: relative;
            display: flex;
            flex-direction: column;
        }
        .id-header {
            background: #004080;
            color: #fff;
            padding: 12px;
            text-align: center;
            border-bottom: 2px solid #000;
        }
        .id-header .university-name {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .id-header .card-title {
            font-size: 14px;
        }
        .id-content {
            padding: 15px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        .id-photo-section {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 15px;
        }
        .photo-label {
            font-weight: bold;
            margin-bottom: 5px;
            font-size: 14px;
        }
        .id-photo {
            width: 120px;
            height: 120px;
            border: 2px solid #004080;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f0f0f0;
            margin-bottom: 10px;
            overflow: hidden;
        }
        .id-photo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .id-validity {
            font-size: 12px;
            text-align: center;
            margin-bottom: 15px;
        }
        .id-info {
            flex: 1;
        }
        .id-info p {
            margin: 8px 0;
            font-size: 14px;
            border-bottom: 1px dotted #eee;
            padding-bottom: 5px;
        }
        .id-info strong {
            display: inline-block;
            width: 100px;
        }
        .id-footer {
            background: #004080;
            color: #fff;
            text-align: center;
            font-size: 12px;
            padding: 8px 0;
            border-top: 2px solid #000;
        }
        .horizontal-line {
            border-top: 1px solid #000;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="id-card">
        <div class="id-header">
            <div class="university-name"><?php echo htmlspecialchars($university_name); ?></div>
            <div class="card-title">Official Identification Card</div>
        </div>

        <div class="id-content">
            <div class="id-photo-section">
                <div class="photo-label">Student Photo</div>
                <div class="id-photo">
                    <img src="<?php echo htmlspecialchars($photo_path); ?>" alt="Student Photo">
                </div>
                <div class="id-validity">
                    Valid until: <?php echo htmlspecialchars($valid_until); ?>
                </div>
            </div>
            
            <div class="id-info">
                <p><strong>Name:</strong> <?php echo htmlspecialchars($full_name); ?></p>
                <p><strong>ID:</strong> <?php echo htmlspecialchars($student_id); ?></p>
                <p><strong>Course:</strong> <?php echo htmlspecialchars($course); ?></p>
                <p><strong>DOB:</strong> <?php echo htmlspecialchars($dob); ?></p>
                <p><strong>Blood Group:</strong> <?php echo htmlspecialchars($blood_group); ?></p>
            </div>
            
            <div class="horizontal-line"></div>
            
            <div style="font-size: 12px; text-align: center; margin-top: 3px;">
                Issued on: <?php echo htmlspecialchars($issued_on); ?><br>
                If found, please return to <?php echo htmlspecialchars($university_name); ?>
            </div>
        </div>

        <div class="id-footer">
            © <?php echo date("Y"); ?> <?php echo htmlspecialchars($university_name); ?>
        </div>
    </div>
</body>
</html>
