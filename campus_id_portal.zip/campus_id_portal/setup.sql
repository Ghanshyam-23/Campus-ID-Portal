-- Create database
CREATE DATABASE IF NOT EXISTS campus_id_portal;
USE campus_id_portal;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    course VARCHAR(100) NOT NULL,
    dob DATE NOT NULL,
    blood_group VARCHAR(5),
    phone VARCHAR(15),
    address TEXT,
    photo_path VARCHAR(255),
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create id_cards table
CREATE TABLE IF NOT EXISTS id_cards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    issued_date DATE NOT NULL,
    expiry_date DATE NOT NULL,
    qr_code VARCHAR(255),
    status ENUM('active', 'expired', 'revoked') DEFAULT 'active',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin user (username: admin, password: admin123)
INSERT INTO admin_users (username, password, full_name) 
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator');

-- Create courses table (optional for dropdowns)
CREATE TABLE IF NOT EXISTS courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(20) NOT NULL,
    course_name VARCHAR(100) NOT NULL,
    duration_years INT DEFAULT 4
);

-- Insert sample courses
INSERT INTO courses (course_code, course_name, duration_years) VALUES
('CS', 'Computer Science', 4),
('EE', 'Electrical Engineering', 4),
('ME', 'Mechanical Engineering', 4),
('CE', 'Civil Engineering', 4),
('BBA', 'Business Administration', 4),
('MBA', 'Master of Business Administration', 2);