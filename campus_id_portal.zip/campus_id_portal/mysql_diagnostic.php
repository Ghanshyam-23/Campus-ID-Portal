<?php
/**
 * MySQL Diagnostic Tool
 * Helps identify and fix MySQL connection issues
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MySQL Diagnostic Tool - Campus ID Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card { margin-bottom: 20px; }
        .success { color: #28a745; }
        .error { color: #dc3545; }
        .warning { color: #ffc107; }
        pre {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="text-center mb-4">
                    <h1>MySQL Connection Diagnostic</h1>
                    <p class="lead">Let's diagnose and fix your MySQL connection issue</p>
                </div>

                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Step 1: Check MySQL Server Status</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        // Check if MySQL port is open
                        function checkMySqlPort($port = 3306) {
                            $connection = @fsockopen('localhost', $port, $errno, $errstr, 2);
                            if (is_resource($connection)) {
                                fclose($connection);
                                return true;
                            }
                            return false;
                        }
                        
                        $mysqlPortOpen = checkMySqlPort(3306) || checkMySqlPort(8889);
                        ?>
                        
                        <p class="<?php echo $mysqlPortOpen ? 'success' : 'error'; ?>">
                            <?php if ($mysqlPortOpen): ?>
                                ✓ MySQL server is running
                            <?php else: ?>
                                ✗ MySQL server is not running on ports 3306 or 8889
                            <?php endif; ?>
                        </p>
                        
                        <?php if (!$mysqlPortOpen): ?>
                            <div class="alert alert-warning">
                                <h6>MySQL server is not running. Please start it:</h6>
                                <ul>
                                    <li><strong>XAMPP:</strong> Start MySQL from the XAMPP Control Panel</li>
                                    <li><strong>WAMP:</strong> Make sure the WAMP icon is green in your system tray</li>
                                    <li><strong>MAMP:</strong> Click "Start Servers" in the MAMP application</li>
                                </ul>
                                <p>Once started, <a href="javascript:location.reload()">refresh this page</a>.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($mysqlPortOpen): ?>
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">Step 2: Test Common MySQL Credentials</h5>
                    </div>
                    <div class="card-body">
                        <p>Testing common MySQL username/password combinations...</p>
                        
                        <?php
                        // Test different credential combinations
                        $credentials = [
                            ['root', '', 3306],
                            ['root', 'root', 3306],
                            ['root', 'password', 3306],
                            ['root', '123456', 3306],
                            ['root', '', 8889],
                            ['root', 'root', 8889],
                        ];
                        
                        $workingCredentials = null;
                        
                        foreach ($credentials as $cred) {
                            list($user, $pass, $port) = $cred;
                            
                            try {
                                $dsn = "mysql:host=localhost;port=$port";
                                $pdo = new PDO($dsn, $user, $pass);
                                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                
                                // Test if we can access mysql database
                                $pdo->exec("USE mysql");
                                $workingCredentials = $cred;
                                break;
                            } catch (PDOException $e) {
                                // Connection failed, try next combination
                                continue;
                            }
                        }
                        ?>
                        
                        <?php if ($workingCredentials): ?>
                            <div class="alert alert-success">
                                <h6>✓ Successfully connected to MySQL!</h6>
                                <p>Working credentials:</p>
                                <ul>
                                    <li>Username: <strong><?php echo $workingCredentials[0]; ?></strong></li>
                                    <li>Password: <strong><?php echo $workingCredentials[1] ?: '(empty)'; ?></strong></li>
                                    <li>Port: <strong><?php echo $workingCredentials[2]; ?></strong></li>
                                </ul>
                                <p>You can now <a href="install.php">proceed with installation</a> using these credentials.</p>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-danger">
                                <h6>✗ Could not connect with any common credentials</h6>
                                <p>This usually means:</p>
                                <ol>
                                    <li>Your MySQL root password is something different</li>
                                    <li>MySQL permissions need to be reset</li>
                                </ol>
                                <p>Continue to the next step to fix this.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0">Step 3: Reset MySQL Password (If Needed)</h5>
                    </div>
                    <div class="card-body">
                        <p>If you don't know your MySQL root password, you can reset it:</p>
                        
                        <div class="accordion" id="resetInstructions">
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#xamppInstructions">
                                        XAMPP Instructions
                                    </button>
                                </h2>
                                <div id="xamppInstructions" class="accordion-collapse collapse show" data-bs-parent="#resetInstructions">
                                    <div class="accordion-body">
                                        <ol>
                                            <li>Open XAMPP Control Panel</li>
                                            <li>Click the "Shell" button</li>
                                            <li>In the command window, type:
                                                <pre>mysqladmin -u root password "newpassword"</pre>
                                                (Replace "newpassword" with your desired password)
                                            </li>
                                            <li>Or to set an empty password:
                                                <pre>mysqladmin -u root password ""</pre>
                                            </li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#wampInstructions">
                                        WAMP Instructions
                                    </button>
                                </h2>
                                <div id="wampInstructions" class="accordion-collapse collapse" data-bs-parent="#resetInstructions">
                                    <div class="accordion-body">
                                        <ol>
                                            <li>Right-click the WAMP system tray icon</li>
                                            <li>Select "MySQL" → "MySQL Console"</li>
                                            <li>Press Enter when prompted for password (if it's currently blank)</li>
                                            <li>At the MySQL prompt, type:
                                                <pre>ALTER USER 'root'@'localhost' IDENTIFIED BY 'newpassword';</pre>
                                                (Replace "newpassword" with your desired password)
                                            </li>
                                            <li>Then type:
                                                <pre>FLUSH PRIVILEGES;</pre>
                                            </li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#mampInstructions">
                                        MAMP Instructions
                                    </button>
                                </h2>
                                <div id="mampInstructions" class="accordion-collapse collapse" data-bs-parent="#resetInstructions">
                                    <div class="accordion-body">
                                        <ol>
                                            <li>Open MAMP</li>
                                            <li>Go to Preferences → PHP</li>
                                            <li>Note the path to the PHP version</li>
                                            <li>Open Terminal and navigate to that path</li>
                                            <li>Type:
                                                <pre>./mysql -u root -p</pre>
                                                (When prompted for password, try "root" first)
                                            </li>
                                            <li>At the MySQL prompt, type:
                                                <pre>ALTER USER 'root'@'localhost' IDENTIFIED BY 'newpassword';</pre>
                                            </li>
                                            <li>Then type:
                                                <pre>FLUSH PRIVILEGES;</pre>
                                            </li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-3">
                            <p>After resetting your password, <a href="javascript:location.reload()">refresh this page</a> to test the new credentials.</p>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">Step 4: Final Installation</h5>
                    </div>
                    <div class="card-body">
                        <p>Once you have working MySQL credentials:</p>
                        <ol>
                            <li>Click the button below to go to the installation page</li>
                            <li>Enter your MySQL username and password</li>
                            <li>Click "Install Database" to set up the Campus ID Portal</li>
                        </ol>
                        
                        <div class="text-center mt-4">
                            <a href="install.php" class="btn btn-primary btn-lg">Proceed to Installation</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>