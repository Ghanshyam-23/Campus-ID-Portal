<?php
/**
 * Test MySQL Credentials
 * Simple form to test your specific MySQL credentials
 */
$host = isset($_POST['host']) ? $_POST['host'] : 'localhost';
$username = isset($_POST['username']) ? $_POST['username'] : 'root';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$port = isset($_POST['port']) ? $_POST['port'] : 3306;

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $dsn = "mysql:host=$host;port=$port";
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Try to access mysql database
        $pdo->exec("USE mysql");
        
        $success = "✓ Successfully connected to MySQL server!";
    } catch (PDOException $e) {
        $error = "✗ Connection failed: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test MySQL Credentials - Campus ID Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Test MySQL Credentials</h3>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success">
                                <?php echo $success; ?>
                                <p class="mt-3">
                                    <a href="install.php" class="btn btn-success">Use These Credentials for Installation</a>
                                </p>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label for="host" class="form-label">Host</label>
                                <input type="text" class="form-control" id="host" name="host" value="<?php echo htmlspecialchars($host); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="port" class="form-label">Port</label>
                                <input type="number" class="form-control" id="port" name="port" value="<?php echo htmlspecialchars($port); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" value="<?php echo htmlspecialchars($password); ?>">
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Test Connection</button>
                            </div>
                        </form>
                        
                        <div class="mt-3">
                            <p class="text-muted">
                                <a href="mysql_diagnostic.php">← Back to Diagnostic Tool</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>