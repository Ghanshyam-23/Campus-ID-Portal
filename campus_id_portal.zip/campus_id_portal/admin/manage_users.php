<?php
session_start();

// Redirect to login if not admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../admin_login.php');
    exit();
}

// Include database configuration
require_once '../includes/config.php';

// Handle user actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $user_id = $_GET['id'];
    $action = $_GET['action'];
    
    if ($action === 'approve') {
        $sql = "UPDATE users SET status = 'approved' WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id', $user_id);
        $stmt->execute();
        
        $_SESSION['message'] = 'User approved successfully.';
    } elseif ($action === 'reject') {
        $sql = "UPDATE users SET status = 'rejected' WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id', $user_id);
        $stmt->execute();
        
        $_SESSION['message'] = 'User rejected successfully.';
    } elseif ($action === 'delete') {
        $sql = "DELETE FROM users WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id', $user_id);
        $stmt->execute();
        
        $_SESSION['message'] = 'User deleted successfully.';
    }
    
    header('Location: manage_users.php');
    exit();
}

// Get filter status
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';

// Build query based on filter
if ($status_filter === 'all') {
    $sql = "SELECT * FROM users ORDER BY created_at DESC";
    $stmt = $pdo->prepare($sql);
} else {
    $sql = "SELECT * FROM users WHERE status = :status ORDER BY created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':status', $status_filter);
}

$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Campus ID Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .sidebar {
            background-color: #212529;
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            padding-top: 20px;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        .sidebar-link {
            color: white;
            padding: 12px 20px;
            display: block;
            text-decoration: none;
            transition: background 0.3s;
        }
        .sidebar-link:hover, .sidebar-link.active {
            background-color: #3a0ca3;
            color: white;
        }
        .status-badge {
            font-size: 0.8rem;
            padding: 0.4em 0.6em;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="px-3">
            <h4 class="text-center mb-4">Admin Panel</h4>
            <div class="text-center my-4">
                <div class="bg-primary rounded-circle d-inline-flex align-items-center justify-content-center" 
                     style="width: 80px; height: 80px;">
                    <i class="bi bi-person-gear" style="font-size: 2rem;"></i>
                </div>
                <p class="mt-2 mb-0">Welcome, <?php echo $_SESSION['admin_name']; ?></p>
                <small class="text-muted">Administrator</small>
            </div>
            
            <hr>
            
            <div class="nav flex-column">
                <a href="index.php" class="sidebar-link">
                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>
                <a href="manage_users.php" class="sidebar-link active">
                    <i class="bi bi-people me-2"></i> Manage Users
                </a>
                <a href="generate_ids.php" class="sidebar-link">
                    <i class="bi bi-credit-card me-2"></i> Generate ID Cards
                </a>
                <a href="../logout.php" class="sidebar-link">
                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                </a>
            </div>
        </div>
    </div>
    
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="bi bi-people me-2"></i> Manage Users</h2>
            <a href="index.php" class="btn btn-secondary">Back to Dashboard</a>
        </div>
        
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
        <?php endif; ?>
        
        <!-- Filter -->
        <div class="card mb-4">
            <div class="card-header bg-light">
                <h5 class="mb-0">Filter Users</h5>
            </div>
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-6">
                        <label for="status" class="form-label">Filter by Status</label>
                        <select class="form-select" id="status" name="status" onchange="this.form.submit()">
                            <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>All Users</option>
                            <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending Approval</option>
                            <option value="approved" <?php echo $status_filter === 'approved' ? 'selected' : ''; ?>>Approved</option>
                            <option value="rejected" <?php echo $status_filter === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="search" class="form-label">Search Users</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="search" name="search" placeholder="Search by name or ID...">
                            <button class="btn btn-primary" type="submit">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Users Table -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Users List</h5>
            </div>
            <div class="card-body">
                <?php if (count($users) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>Student ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Course</th>
                                    <th>Status</th>
                                    <th>Registered On</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($user['student_id']); ?></td>
                                        <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td><?php echo htmlspecialchars($user['course']); ?></td>
                                        <td>
                                            <?php if ($user['status'] == 'approved'): ?>
                                                <span class="badge bg-success status-badge">Approved</span>
                                            <?php elseif ($user['status'] == 'pending'): ?>
                                                <span class="badge bg-warning status-badge">Pending</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger status-badge">Rejected</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                        <td>
                                            <a href="view_user.php?id=<?php echo $user['id']; ?>" class="btn btn-sm btn-info" title="View Details">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <?php if ($user['status'] === 'pending'): ?>
                                                <a href="manage_users.php?action=approve&id=<?php echo $user['id']; ?>" class="btn btn-sm btn-success" title="Approve">
                                                    <i class="bi bi-check-circle"></i>
                                                </a>
                                                <a href="manage_users.php?action=reject&id=<?php echo $user['id']; ?>" class="btn btn-sm btn-danger" title="Reject">
                                                    <i class="bi bi-x-circle"></i>
                                                </a>
                                            <?php endif; ?>
                                            <a href="manage_users.php?action=delete&id=<?php echo $user['id']; ?>" class="btn btn-sm btn-outline-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this user?')">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="bi bi-people" style="font-size: 3rem; color: #6c757d;"></i>
                        <h5 class="mt-3">No users found</h5>
                        <p class="text-muted">There are no users in the system yet.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>