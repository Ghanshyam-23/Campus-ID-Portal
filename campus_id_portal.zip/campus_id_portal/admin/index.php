<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Redirect to login if not admin
if (!isAdmin()) {
    header('Location: ../login.php');
    exit();
}

// Get statistics for dashboard
$sql = "SELECT 
        COUNT(*) as total_users,
        SUM(status = 'pending') as pending_users,
        SUM(status = 'approved') as approved_users,
        SUM(status = 'rejected') as rejected_users
        FROM users";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

// Get recent pending registrations
$sql = "SELECT * FROM users WHERE status = 'pending' ORDER BY created_at DESC LIMIT 5";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$pending_users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Campus ID Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container-fluid mt-5">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 bg-dark text-white vh-100 position-fixed" id="sidebar">
                <div class="p-4">
                    <h5 class="text-center mb-4">Admin Panel</h5>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active text-white" href="index.php">
                                <i class="bi bi-speedometer2 me-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="manage_users.php">
                                <i class="bi bi-people me-2"></i> Manage Users
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="generate_ids.php">
                                <i class="bi bi-credit-card me-2"></i> Generate ID Cards
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="../logout.php">
                                <i class="bi bi-box-arrow-right me-2"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Main content -->
            <div class="col-md-9 col-lg-10 ms-auto">
                <div class="p-4">
                    <h2 class="mb-4">Admin Dashboard</h2>
                    
                    <!-- Statistics Cards -->
                    <div class="row mb-4">
                        <div class="col-md-3">
                            <div class="card bg-primary text-white">
                                <div class="card-body">
                                    <h5 class="card-title">Total Users</h5>
                                    <h2 class="card-text"><?php echo $stats['total_users']; ?></h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-warning text-dark">
                                <div class="card-body">
                                    <h5 class="card-title">Pending Approval</h5>
                                    <h2 class="card-text"><?php echo $stats['pending_users']; ?></h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-success text-white">
                                <div class="card-body">
                                    <h5 class="card-title">Approved Users</h5>
                                    <h2 class="card-text"><?php echo $stats['approved_users']; ?></h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-danger text-white">
                                <div class="card-body">
                                    <h5 class="card-title">Rejected Users</h5>
                                    <h2 class="card-text"><?php echo $stats['rejected_users']; ?></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Pending Registrations -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="card-title">Recent Pending Registrations</h5>
                        </div>
                        <div class="card-body">
                            <?php if (count($pending_users) > 0): ?>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Student ID</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Course</th>
                                                <th>Registered On</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($pending_users as $user): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($user['student_id']); ?></td>
                                                    <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                                    <td><?php echo htmlspecialchars($user['course']); ?></td>
                                                    <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                                    <td>
                                                        <a href="manage_users.php?action=view&id=<?php echo $user['id']; ?>" class="btn btn-sm btn-info">View</a>
                                                        <a href="manage_users.php?action=approve&id=<?php echo $user['id']; ?>" class="btn btn-sm btn-success">Approve</a>
                                                        <a href="manage_users.php?action=reject&id=<?php echo $user['id']; ?>" class="btn btn-sm btn-danger">Reject</a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="text-end">
                                    <a href="manage_users.php?status=pending" class="btn btn-primary">View All Pending</a>
                                </div>
                            <?php else: ?>
                                <p class="text-center">No pending registrations.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Quick Actions -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Quick Actions</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2 d-md-flex">
                                <a href="manage_users.php" class="btn btn-primary me-md-2">Manage Users</a>
                                <a href="generate_ids.php" class="btn btn-success me-md-2">Generate ID Cards</a>
                                <a href="../logout.php" class="btn btn-outline-danger">Logout</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>