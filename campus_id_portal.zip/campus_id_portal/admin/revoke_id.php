<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Redirect to login if not admin
if (!isAdmin()) {
    header('Location: ../login.php');
    exit();
}

// Get ID card ID from URL
if (!isset($_GET['id'])) {
    header('Location: generate_ids.php');
    exit();
}

$id_card_id = $_GET['id'];

// Revoke the ID card
$sql = "UPDATE id_cards SET status = 'revoked' WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':id', $id_card_id);
$stmt->execute();

$_SESSION['message'] = 'ID card revoked successfully.';
header('Location: generate_ids.php');
exit();
?>