<?php
session_start();

// Redirect to login if not admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../admin_login.php');
    exit();
}

// Include database configuration
require_once '../includes/config.php';

// Get user ID from URL
if (!isset($_GET['id'])) {
    header('Location: manage_users.php');
    exit();
}

$user_id = $_GET['id'];

// Get user details
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':id', $user_id);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    header('Location: manage_users.php');
    exit();
}

// Get ID card if exists
$id_card = null;
$sql = "SELECT * FROM id_cards WHERE user_id = :user_id";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();
if ($stmt->rowCount() > 0) {
    $id_card = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View User - Campus ID Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .sidebar {
            background-color: #212529;
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            padding-top: 20px;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        .sidebar-link {
            color: white;
            padding: 12px 20px;
            display: block;
            text-decoration: none;
            transition: background 0.3s;
        }
        .sidebar-link:hover, .sidebar-link.active {
            background-color: #3a0ca3;
            color: white;
        }
        .profile-img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border: 3px solid #dee2e6;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="px-3">
            <h4 class="text-center mb-4">Admin Panel</h4>
            <div class="text-center my-4">
                <div class="bg-primary rounded-circle d-inline-flex align-items-center justify-content-center" 
                     style="width: 80px; height: 80px;">
                    <i class="bi bi-person-gear" style="font-size: 2rem;"></i>
                </div>
                <p class="mt-2 mb-0">Welcome, <?php echo $_SESSION['admin_name']; ?></p>
                <small class="text-muted">Administrator</small>
            </div>
            
            <hr>
            
            <div class="nav flex-column">
                <a href="index.php" class="sidebar-link">
                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>
                <a href="manage_users.php" class="sidebar-link active">
                    <i class="bi bi-people me-2"></i> Manage Users
                </a>
                <a href="generate_ids.php" class="sidebar-link">
                    <i class="bi bi-credit-card me-2"></i> Generate ID Cards
                </a>
                <a href="../logout.php" class="sidebar-link">
                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                </a>
            </div>
        </div>
    </div>
    
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="bi bi-person me-2"></i> User Details</h2>
            <a href="manage_users.php" class="btn btn-secondary">
                <i class="bi bi-arrow-left me-1"></i> Back to Users
            </a>
        </div>
        
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Profile Photo</h5>
                    </div>
                    <div class="card-body text-center">
                        <?php if ($user['photo_path'] && file_exists('../' . $user['photo_path'])): ?>
                            <img src="../<?php echo $user['photo_path']; ?>" class="profile-img rounded-circle mb-3" alt="Profile Photo">
                        <?php else: ?>
                            <div class="bg-secondary rounded-circle d-flex align-items-center justify-content-center mb-3 mx-auto" style="width: 150px; height: 150px;">
                                <span class="text-white">No Photo</span>
                            </div>
                        <?php endif; ?>
                        
                        <h4><?php echo htmlspecialchars($user['full_name']); ?></h4>
                        <p class="text-muted"><?php echo htmlspecialchars($user['student_id']); ?></p>
                        
                        <?php if ($user['status'] == 'approved'): ?>
                            <span class="badge bg-success">Approved</span>
                        <?php elseif ($user['status'] == 'pending'): ?>
                            <span class="badge bg-warning">Pending Approval</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Rejected</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">Personal Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Student ID:</strong> <?php echo htmlspecialchars($user['student_id']); ?></p>
                                <p><strong>Full Name:</strong> <?php echo htmlspecialchars($user['full_name']); ?></p>
                                <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                                <p><strong>Phone:</strong> <?php echo htmlspecialchars($user['phone'] ?: 'N/A'); ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Course:</strong> <?php echo htmlspecialchars($user['course']); ?></p>
                                <p><strong>Date of Birth:</strong> <?php echo date('M d, Y', strtotime($user['dob'])); ?></p>
                                <p><strong>Blood Group:</strong> <?php echo htmlspecialchars($user['blood_group'] ?: 'N/A'); ?></p>
                                <p><strong>Status:</strong> 
                                    <?php if ($user['status'] == 'approved'): ?>
                                        <span class="badge bg-success">Approved</span>
                                    <?php elseif ($user['status'] == 'pending'): ?>
                                        <span class="badge bg-warning">Pending</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Rejected</span>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                        
                        <p><strong>Address:</strong> <?php echo htmlspecialchars($user['address'] ?: 'N/A'); ?></p>
                        <p><strong>Registered on:</strong> <?php echo date('M d, Y', strtotime($user['created_at'])); ?></p>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">ID Card Information</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($id_card): ?>
                            <div class="alert alert-success">
                                <h6>ID Card is Active</h6>
                                <p><strong>Issued on:</strong> <?php echo date('M d, Y', strtotime($id_card['issued_date'])); ?></p>
                                <p><strong>Expires on:</strong> <?php echo date('M d, Y', strtotime($id_card['expiry_date'])); ?></p>
                                <p><strong>Status:</strong> 
                                    <?php if ($id_card['status'] == 'active'): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php elseif ($id_card['status'] == 'expired'): ?>
                                        <span class="badge bg-warning">Expired</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Revoked</span>
                                    <?php endif; ?>
                                </p>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex">
                                <a href="../generate_id_card.php?id=<?php echo $id_card['id']; ?>" class="btn btn-info me-md-2" target="_blank">
                                    <i class="bi bi-eye me-1"></i> View ID Card
                                </a>
                                <a href="../generate_id_card.php?id=<?php echo $id_card['id']; ?>&download=1" class="btn btn-primary me-md-2">
                                    <i class="bi bi-download me-1"></i> Download ID Card
                                </a>
                                <?php if ($id_card['status'] === 'active'): ?>
                                    <a href="revoke_id.php?id=<?php echo $id_card['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to revoke this ID card?')">
                                        <i class="bi bi-x-circle me-1"></i> Revoke ID Card
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <h6>No ID Card Generated</h6>
                                <p>This user does not have an ID card yet.</p>
                                <?php if ($user['status'] === 'approved'): ?>
                                    <a href="generate_ids.php" class="btn btn-primary">Generate ID Card</a>
                                <?php else: ?>
                                    <p class="text-muted">User must be approved first before generating an ID card.</p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>