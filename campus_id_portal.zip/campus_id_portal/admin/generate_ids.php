<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Redirect to login if not admin
if (!isAdmin()) {
    header('Location: ../login.php');
    exit();
}

// Handle ID card generation
if (isset($_POST['generate_id_card'])) {
    $user_id = $_POST['user_id'];
    $expiry_date = $_POST['expiry_date'];
    
    $sql = "SELECT * FROM id_cards WHERE user_id = :user_id AND status = 'active'";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        $_SESSION['error'] = 'User already has an active ID card.';
    } else {

        $qr_data = uniqid('id_', true);
        
        $sql = "INSERT INTO id_cards (user_id, issued_date, expiry_date, qr_code) 
                VALUES (:user_id, CURDATE(), :expiry_date, :qr_code)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':expiry_date', $expiry_date);
        $stmt->bindParam(':qr_code', $qr_data);
        
        if ($stmt->execute()) {
            $_SESSION['message'] = 'ID card generated successfully.';
        } else {
            $_SESSION['error'] = 'Failed to generate ID card.';
        }
    }
    
    header('Location: generate_ids.php');
    exit();
}

// Get approved users without active ID cards
$sql = "SELECT * FROM users WHERE status = 'approved' AND id NOT IN 
        (SELECT user_id FROM id_cards WHERE status = 'active')";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$users_without_id = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all ID cards
$sql = "SELECT ic.*, u.student_id, u.full_name, u.course 
        FROM id_cards ic 
        JOIN users u ON ic.user_id = u.id 
        ORDER BY ic.issued_date DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$id_cards = $stmt->fetchAll(PDO::FETCH_ASSOC);


// BONAFIDE REQUEST QUERY
$sql = "SELECT id, student_id, full_name, course 
        FROM users 
        WHERE bonafide_status='pending'";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$bonafide_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Generate ID Cards - Campus ID Portal</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

<?php include '../includes/header.php'; ?>

<div class="container-fluid mt-5">
<div class="row">

<!-- Sidebar -->

<div class="col-md-3 col-lg-2 bg-dark text-white vh-100 position-fixed" id="sidebar">

<div class="p-4">

<h5 class="text-center mb-4">Admin Panel</h5>

<ul class="nav flex-column">

<li class="nav-item">
<a class="nav-link text-white" href="index.php">
Dashboard
</a>
</li>

<li class="nav-item">
<a class="nav-link text-white" href="manage_users.php">
Manage Users
</a>
</li>

<li class="nav-item">
<a class="nav-link active text-white" href="generate_ids.php">
Generate ID Cards
</a>
</li>

<li class="nav-item">
<a class="nav-link text-white" href="../logout.php">
Logout
</a>
</li>

</ul>

</div>
</div>


<!-- Main Content -->

<div class="col-md-9 col-lg-10 ms-auto">

<div class="p-4">

<h2 class="mb-4">Generate ID Cards</h2>


<?php if (isset($_SESSION['message'])): ?>
<div class="alert alert-success">
<?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
</div>
<?php endif; ?>


<?php if (isset($_SESSION['error'])): ?>
<div class="alert alert-danger">
<?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
</div>
<?php endif; ?>


<!-- Generate ID Card Form -->

<div class="card mb-4">

<div class="card-header">
<h5 class="card-title">Generate New ID Card</h5>
</div>

<div class="card-body">

<form method="POST">

<div class="row">

<div class="col-md-6">

<div class="mb-3">

<label class="form-label">Select Student</label>

<select class="form-select" name="user_id" required>

<option value="">Select Student</option>

<?php foreach ($users_without_id as $user): ?>

<option value="<?php echo $user['id']; ?>">

<?php echo htmlspecialchars($user['student_id'].' - '.$user['full_name'].' ('.$user['course'].')'); ?>

</option>

<?php endforeach; ?>

</select>

</div>
</div>


<div class="col-md-6">

<div class="mb-3">

<label class="form-label">Expiry Date</label>

<input type="date" name="expiry_date" class="form-control" required>

</div>

</div>

</div>


<div class="text-end">

<button type="submit" name="generate_id_card" class="btn btn-primary">

Generate ID Card

</button>

</div>

</form>

</div>

</div>


<!-- ID CARDS LIST -->

<div class="card">

<div class="card-header">

<h5 class="card-title">Generated ID Cards</h5>

</div>


<div class="card-body">

<?php if (count($id_cards) > 0): ?>

<div class="table-responsive">

<table class="table table-striped">

<thead>

<tr>

<th>Student ID</th>
<th>Name</th>
<th>Course</th>
<th>Issued Date</th>
<th>Expiry Date</th>
<th>Status</th>
<th>Actions</th>

</tr>

</thead>

<tbody>

<?php foreach ($id_cards as $card): ?>

<tr>

<td><?php echo $card['student_id']; ?></td>
<td><?php echo $card['full_name']; ?></td>
<td><?php echo $card['course']; ?></td>

<td><?php echo date('M d, Y', strtotime($card['issued_date'])); ?></td>

<td><?php echo date('M d, Y', strtotime($card['expiry_date'])); ?></td>

<td>
<span class="badge bg-success">
<?php echo ucfirst($card['status']); ?>
</span>
</td>

<td>

<a href="../generate_id_card.php?id=<?php echo $card['id']; ?>" class="btn btn-sm btn-info">View</a>

<a href="../generate_id_card.php?id=<?php echo $card['id']; ?>&download=1" class="btn btn-sm btn-primary">Download</a>

<a href="revoke_id.php?id=<?php echo $card['id']; ?>" class="btn btn-sm btn-danger">Revoke</a>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

<?php else: ?>

<p class="text-center">No ID cards generated yet.</p>

<?php endif; ?>

</div>

</div>


<!-- BONAFIDE REQUEST SECTION -->

<div class="card mt-4">

<div class="card-header">

<h5 class="card-title">Bonafide Certificate Requests</h5>

</div>


<div class="card-body">

<?php if(count($bonafide_requests) > 0): ?>

<table class="table table-striped">

<thead>

<tr>

<th>Student ID</th>
<th>Name</th>
<th>Course</th>
<th>Action</th>

</tr>

</thead>

<tbody>

<?php foreach($bonafide_requests as $req): ?>

<tr>

<td><?php echo $req['student_id']; ?></td>

<td><?php echo $req['full_name']; ?></td>

<td><?php echo $req['course']; ?></td>

<td>

<a href="approve_bonafide.php?id=<?php echo $req['id']; ?>" 
class="btn btn-success btn-sm">

Approve Bonafide

</a>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

<?php else: ?>

<p class="text-center">No pending bonafide requests.</p>

<?php endif; ?>

</div>

</div>

</div>

</div>

</div>

</div>

<?php include '../includes/footer.php'; ?>

</body>
</html>