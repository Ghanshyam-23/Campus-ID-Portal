<?php
session_start();
require_once '../includes/config.php';

if(!isset($_GET['id'])){
    header("Location: generate_ids.php");
    exit();
}

$id = $_GET['id'];

$sql = "UPDATE users SET bonafide_status='approved' WHERE id=:id";

$stmt = $pdo->prepare($sql);
$stmt->bindParam(':id',$id);
$stmt->execute();

header("Location: generate_ids.php");
exit();
?>