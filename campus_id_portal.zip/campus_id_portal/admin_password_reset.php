<?php
session_start();

// Database connection
$host = 'localhost';
$dbname = 'campus_id_portal';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    
    if ($action === 'reset_password') {
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if (empty($new_password) || empty($confirm_password)) {
            $error = 'Please enter both password fields.';
        } elseif ($new_password !== $confirm_password) {
            $error = 'Passwords do not match.';
        } else {
            // Reset admin password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $sql = "UPDATE admin_users SET password = :password WHERE username = 'admin'";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':password', $hashed_password);
            
            if ($stmt->execute()) {
                $message = 'Admin password reset successfully!';
            } else {
                $error = 'Failed to reset password.';
            }
        }
    } elseif ($action === 'create_admin') {
        // Create admin user if doesn't exist
        $admin_password = password_hash('admin123', PASSWORD_DEFAULT);
        $sql = "INSERT INTO admin_users (username, password, full_name) 
                VALUES ('admin', '$admin_password', 'Administrator')";
        try {
            $pdo->exec($sql);
            $message = 'Admin user created successfully!';
        } catch (PDOException $e) {
            // If admin already exists, just update the password
            $admin_password = password_hash('admin123', PASSWORD_DEFAULT);
            $sql = "UPDATE admin_users SET password = '$admin_password' WHERE username = 'admin'";
            $pdo->exec($sql);
            $message = 'Admin password reset to default (admin123)!';
        }
    }
}

// Check if admin user exists
$admin_exists = $pdo->query("SELECT COUNT(*) as count FROM admin_users WHERE username = 'admin'")->fetch()['count'] > 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Password Reset - Campus ID Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #3a0ca3, #4361ee);
            height: 100vh;
            display: flex;
            align-items: center;
        }
        .reset-card {
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            background: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card reset-card">
                    <div class="card-header bg-primary text-white text-center py-4">
                        <h3><i class="bi bi-key"></i> Admin Password Reset</h3>
                        <p class="mb-0">Campus ID Portal System</p>
                    </div>
                    <div class="card-body p-4">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($message): ?>
                            <div class="alert alert-success">
                                <?php echo $message; ?>
                                <p class="mt-3">
                                    <a href="admin_login.php" class="btn btn-success">Go to Admin Login</a>
                                </p>
                            </div>
                        <?php else: ?>
                            <?php if (!$admin_exists): ?>
                                <div class="alert alert-warning">
                                    <h5>Admin User Not Found!</h5>
                                    <p>No admin user exists in the database. Click the button below to create one.</p>
                                    <form method="POST">
                                        <input type="hidden" name="action" value="create_admin">
                                        <button type="submit" class="btn btn-warning">Create Admin User</button>
                                    </form>
                                </div>
                            <?php else: ?>
                                <p class="text-muted">Use this tool to reset the admin password.</p>
                                
                                <form method="POST">
                                    <input type="hidden" name="action" value="reset_password">
                                    
                                    <div class="mb-3">
                                        <label for="new_password" class="form-label">New Password</label>
                                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="confirm_password" class="form-label">Confirm Password</label>
                                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                    </div>
                                    
                                    <div class="d-grid">
                                        <button type="submit" class="btn btn-primary">Reset Password</button>
                                    </div>
                                </form>
                                
                                <div class="text-center mt-4">
                                    <div class="alert alert-info">
                                        <h6>Default Admin Credentials</h6>
                                        <p class="mb-1"><strong>Username:</strong> admin</p>
                                        <p class="mb-0"><strong>Password:</strong> admin123</p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                        <hr>
                        
                        <div class="text-center">
                            <a href="admin_login.php" class="btn btn-outline-secondary">Admin Login</a>
                            <a href="index.php" class="btn btn-link">Back to Home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>