<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':id',$user_id);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

/* Default purpose */
$purpose = "For official and academic purposes.";
?>

<!DOCTYPE html>
<html>
<head>
<title>Bonafide Certificate</title>

<style>

body{
font-family: "Times New Roman", serif;
background:#f5f5f5;
}

.certificate{
width:800px;
margin:40px auto;
background:white;
padding:40px;
border:2px solid black;
}

.header-line{
border-top:2px solid black;
border-bottom:2px solid black;
padding:10px 0;
text-align:center;
font-weight:bold;
}

.title{
text-align:center;
font-size:24px;
margin-top:20px;
text-decoration:underline;
}

.content{
margin-top:30px;
line-height:1.8;
font-size:18px;
}

.sign{
margin-top:80px;
display:flex;
justify-content:space-between;
}

</style>

</head>

<body>

<div class="certificate">

<div class="header-line">

<?php echo htmlspecialchars($user['college_name']); ?><br>
Chhatrapati Sambhajinagar, Maharashtra – 431001<br>
(Affiliated to <?php echo htmlspecialchars($user['university_name']); ?>)

</div>

<div class="title">
BONAFIDE CERTIFICATE
</div>

<div class="content">

<p>Date: <?php echo date("d-m-Y"); ?></p>

<p>
This is to certify that <b>Mr./Ms. <?php echo htmlspecialchars($user['full_name']); ?></b>
(Student ID: <b><?php echo htmlspecialchars($user['student_id']); ?></b>)
</p>

<p>
Date of Birth: <b><?php echo date("d-m-Y", strtotime($user['dob'])); ?></b>
</p>

<p>
is a bonafide student of our institution studying in the course
<b><?php echo htmlspecialchars($user['course']); ?></b>
during the academic year <b>2025 - 2026</b>.
</p>

<p>
This certificate is issued on the request of the student
for the purpose of 
<b><?php echo $purpose; ?></b>.
</p>

<p>
We wish him/her success in all future endeavors.
</p>

<p>Place: Pune</p>

</div>

<div class="sign">

<div>
__________________________<br>
Class Coordinator
</div>

<div>
__________________________<br>
Principal<br>
<?php echo htmlspecialchars($user['university_name']); ?>
</div>

</div>

<p style="margin-top:40px;">(Official Seal)</p>

</div>

</body>
</html>