<?php
/**
 * MySQL Password Reset Guide
 * This is not an automatic reset, but a guide to reset MySQL password
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MySQL Password Reset Guide - Campus ID Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">MySQL Password Reset Guide</h3>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <h5>If you've forgotten your MySQL root password</h5>
                            <p>Here's how to reset it:</p>
                        </div>
                        
                        <h4>For XAMPP:</h4>
                        <ol>
                            <li>Open XAMPP Control Panel</li>
                            <li>Click "Shell" button</li>
                            <li>Type: <code>mysqladmin -u root password</code> (to set empty password)</li>
                            <li>Or: <code>mysqladmin -u root password "newpassword"</code></li>
                        </ol>
                        
                        <h4>For WAMP:</h4>
                        <ol>
                            <li>Right-click WAMP system tray icon</li>
                            <li>Select "MySQL" → "MySQL Console"</li>
                            <li>Press Enter without password</li>
                            <li>Type: <code>ALTER USER 'root'@'localhost' IDENTIFIED BY 'newpassword';</code></li>
                            <li>Then: <code>FLUSH PRIVILEGES;</code></li>
                        </ol>
                        
                        <h4>For MAMP:</h4>
                        <ol>
                            <li>Open MAMP</li>
                            <li>Go to Preferences → PHP</li>
                            <li>Note the path to the PHP version</li>
                            <li>Open Terminal and navigate to that path</li>
                            <li>Type: <code>./mysql -u root -p</code> (password is usually "root")</li>
                            <li>Then use the ALTER USER command as above</li>
                        </ol>
                        
                        <h4>Alternative Solution:</h4>
                        <p>If you can't remember your password, you might need to reinstall your server software:</p>
                        <ol>
                            <li>Backup your databases if possible</li>
                            <li>Uninstall XAMPP/WAMP/MAMP</li>
                            <li>Reinstall with default settings</li>
                            <li>Use the default credentials (usually root with no password)</li>
                        </ol>
                        
                        <div class="text-center mt-4">
                            <a href="install.php" class="btn btn-primary">Return to Installation</a>
                            <a href="check_mysql.php" class="btn btn-secondary">Check MySQL Status</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>