<?php
/**
 * Installation Script for Campus ID Portal
 * This script will help you set up the database
 */

// Default values
$host = isset($_POST['host']) ? $_POST['host'] : 'localhost';
$username = isset($_POST['username']) ? $_POST['username'] : 'root';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$port = isset($_POST['port']) ? $_POST['port'] : 3306;
$createNewDb = isset($_POST['create_db']);

$error = '';
$success = '';
$pdo = null;

// Try to connect
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $dsn = "mysql:host=$host;port=$port";
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        if ($createNewDb) {
            // Create database
            $pdo->exec("CREATE DATABASE IF NOT EXISTS campus_id_portal");
            $pdo->exec("USE campus_id_portal");
            
            // Read and execute SQL file
            $sql = file_get_contents('database/setup.sql');
            $pdo->exec($sql);
            
            $success = "Database created successfully!";
            
            // Update config file
            $config_content = "<?php
// Database configuration
\$host = '$host';
\$dbname = 'campus_id_portal';
\$username = '$username';
\$password = '$password';";

            if ($port != 3306) {
                $config_content .= "\n\$port = $port;";
            }

            $config_content .= "

// Attempt to connect to MySQL database
try {
    if (isset(\$port)) {
        \$pdo = new PDO(\"mysql:host=\$host;port=\$port;dbname=\$dbname\", \$username, \$password);
    } else {
        \$pdo = new PDO(\"mysql:host=\$host;dbname=\$dbname\", \$username, \$password);
    }
    \$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException \$e) {
    die(\"Database connection failed: \" . \$e->getMessage());
}

// Set timezone
date_default_timezone_set('UTC');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Define base URL
define('BASE_URL', 'http://' . \$_SERVER['HTTP_HOST'] . '/campus-id-portal/');

// Include functions
require_once 'functions.php';
?>";

            file_put_contents('includes/config.php', $config_content);
        }
        
    } catch (PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install Campus ID Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Install Campus ID Portal</h3>
                    </div>
                    <div class="card-body">
                        <?php if ($error && !$createNewDb): ?>
                            <div class="alert alert-danger">
                                <h5>Connection Failed</h5>
                                <p><?php echo $error; ?></p>
                                <p>Please check:</p>
                                <ol>
                                    <li>Is MySQL server running? <a href="check_mysql.php">Check status</a></li>
                                    <li>Are your credentials correct?</li>
                                    <li>Do you need to reset your MySQL password? <a href="reset_mysql_password.php">Guide here</a></li>
                                </ol>
                            </div>
                        <?php elseif ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success">
                                <?php echo $success; ?>
                                <p class="mt-3">
                                    <a href="index.php" class="btn btn-success">Go to Website</a>
                                    <a href="login.php" class="btn btn-primary">Login</a>
                                </p>
                                <p>Admin login: username <strong>admin</strong>, password <strong>admin123</strong></p>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">Please enter your MySQL database credentials to set up the application.</p>
                            
                            <form method="POST">
                                <div class="mb-3">
                                    <label for="host" class="form-label">Host</label>
                                    <input type="text" class="form-control" id="host" name="host" value="<?php echo htmlspecialchars($host); ?>" required>
                                    <div class="form-text">Usually 'localhost' or '127.0.0.1'</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="port" class="form-label">Port</label>
                                    <input type="number" class="form-control" id="port" name="port" value="<?php echo htmlspecialchars($port); ?>" required>
                                    <div class="form-text">Usually 3306, or 8889 for MAMP</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
                                    <div class="form-text">Usually 'root'</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="password" class="form-control" id="password" name="password" value="<?php echo htmlspecialchars($password); ?>">
                                    <div class="form-text">Leave empty if no password</div>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" name="test_connection" class="btn btn-info mb-2">Test Connection</button>
                                    <button type="submit" name="create_db" class="btn btn-primary">Install Database</button>
                                </div>
                            </form>
                            
                            <div class="mt-3">
                                <p class="text-muted">
                                    Not sure about your credentials? 
                                    <a href="check_mysql.php">Check MySQL status</a> or 
                                    <a href="reset_mysql_password.php">reset password</a>
                                </p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>