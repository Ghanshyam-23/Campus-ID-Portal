<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

requireLogin();

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Get user data
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':id', $user_id);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitizeInput($_POST['full_name']);
    $course = sanitizeInput($_POST['course']);
    $blood_group = sanitizeInput($_POST['blood_group']);
    $phone = sanitizeInput($_POST['phone']);
    $address = sanitizeInput($_POST['address']);
    
    // Handle photo upload if provided
    $photo_path = $user['photo_path'];
    if (!empty($_FILES['photo']['name'])) {
        $upload_result = uploadPhoto($_FILES['photo']);
        if ($upload_result['success']) {
            $photo_path = $upload_result['file_path'];
            // Delete old photo if exists
            if ($user['photo_path'] && file_exists($user['photo_path'])) {
                unlink($user['photo_path']);
            }
        } else {
            $error = $upload_result['message'];
        }
    }
    
    if (empty($error)) {
        $sql = "UPDATE users SET full_name = :full_name, course = :course, blood_group = :blood_group, 
                phone = :phone, address = :address, photo_path = :photo_path WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':full_name', $full_name);
        $stmt->bindParam(':course', $course);
        $stmt->bindParam(':blood_group', $blood_group);
        $stmt->bindParam(':phone', $phone);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':photo_path', $photo_path);
        $stmt->bindParam(':id', $user_id);
        
        if ($stmt->execute()) {
            $success = 'Profile updated successfully!';
            // Refresh user data
            $sql = "SELECT * FROM users WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':id', $user_id);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            $_SESSION['full_name'] = $user['full_name'];
        } else {
            $error = 'Failed to update profile. Please try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile - Campus ID Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Update Profile</h3>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data" class="needs-validation" novalidate>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="full_name" class="form-label">Full Name *</label>
                                        <input type="text" class="form-control" id="full_name" name="full_name" 
                                               value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                                        <div class="invalid-feedback">
                                            Please provide your full name.
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="course" class="form-label">Course/Department *</label>
                                        <input type="text" class="form-control" id="course" name="course" 
                                               value="<?php echo htmlspecialchars($user['course']); ?>" required>
                                        <div class="invalid-feedback">
                                            Please provide your course/department.
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="blood_group" class="form-label">Blood Group</label>
                                        <select class="form-select" id="blood_group" name="blood_group">
                                            <option value="">Select Blood Group</option>
                                            <option value="A+" <?php echo $user['blood_group'] == 'A+' ? 'selected' : ''; ?>>A+</option>
                                            <option value="A-" <?php echo $user['blood_group'] == 'A-' ? 'selected' : ''; ?>>A-</option>
                                            <option value="B+" <?php echo $user['blood_group'] == 'B+' ? 'selected' : ''; ?>>B+</option>
                                            <option value="B-" <?php echo $user['blood_group'] == 'B-' ? 'selected' : ''; ?>>B-</option>
                                            <option value="AB+" <?php echo $user['blood_group'] == 'AB+' ? 'selected' : ''; ?>>AB+</option>
                                            <option value="AB-" <?php echo $user['blood_group'] == 'AB-' ? 'selected' : ''; ?>>AB-</option>
                                            <option value="O+" <?php echo $user['blood_group'] == 'O+' ? 'selected' : ''; ?>>O+</option>
                                            <option value="O-" <?php echo $user['blood_group'] == 'O-' ? 'selected' : ''; ?>>O-</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="phone" class="form-label">Phone Number</label>
                                        <input type="tel" class="form-control" id="phone" name="phone" 
                                               value="<?php echo htmlspecialchars($user['phone']); ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="address" class="form-label">Address</label>
                                        <textarea class="form-control" id="address" name="address" rows="3"><?php echo htmlspecialchars($user['address']); ?></textarea>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="photo" class="form-label">Profile Photo</label>
                                        <input type="file" class="form-control" id="photo" name="photo" accept="image/*" onchange="previewImage(this)">
                                        <div class="form-text">Current photo:</div>
                                        <?php if ($user['photo_path']): ?>
                                            <img src="<?php echo $user['photo_path']; ?>" id="photo-preview" class="img-thumbnail mt-2" style="max-height: 150px;">
                                        <?php else: ?>
                                            <div class="text-muted mt-2">No photo uploaded</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Update Profile</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <div class="text-center mt-3">
                    <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
                </div>
            </div>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>