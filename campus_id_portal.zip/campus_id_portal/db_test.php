<?php
/**
 * Database Connection Tester
 * Use this script to test your database connection settings
 */

// Try different connection configurations
$configs = [
    ['host' => 'localhost', 'user' => 'root', 'pass' => '', 'port' => 3306],
    ['host' => 'localhost', 'user' => 'root', 'pass' => 'root', 'port' => 3306],
    ['host' => '127.0.0.1', 'user' => 'root', 'pass' => '', 'port' => 3306],
    ['host' => '127.0.0.1', 'user' => 'root', 'pass' => 'root', 'port' => 3306],
];

// For MAMP users
$configs[] = ['host' => 'localhost', 'user' => 'root', 'pass' => 'root', 'port' => 8889];
$configs[] = ['host' => '127.0.0.1', 'user' => 'root', 'pass' => 'root', 'port' => 8889];

echo "<h2>Database Connection Tester</h2>";

foreach ($configs as $config) {
    echo "<h3>Trying: {$config['user']}@{$config['host']}:{$config['port']}</h3>";
    
    try {
        $dsn = "mysql:host={$config['host']};port={$config['port']}";
        $pdo = new PDO($dsn, $config['user'], $config['pass']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        echo "<p style='color: green;'>✓ Connection successful!</p>";
        
        // Try to select database
        try {
            $pdo->exec("USE campus_id_portal");
            echo "<p style='color: green;'>✓ Database 'campus_id_portal' exists and accessible</p>";
        } catch (PDOException $e) {
            echo "<p style='color: orange;'>⚠ Database 'campus_id_portal' doesn't exist or not accessible: " . $e->getMessage() . "</p>";
        }
        
        break; // Stop when we find a working configuration
    } catch (PDOException $e) {
        echo "<p style='color: red;'>✗ Connection failed: " . $e->getMessage() . "</p>";
    }
}

echo "<hr><h3>Next Steps:</h3>";
echo "<ol>
<li>Note which connection worked above</li>
<li>Update includes/config.php with the working credentials</li>
<li>If database doesn't exist, run the SQL script from database/setup.sql</li>
</ol>";

echo "<p><a href='install.php'>Run Installation Script</a></p>";
?>