<?php
/**
 * MySQL Password Discovery Tool
 * Helps find your current MySQL root password
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Find MySQL Password - Campus ID Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h3 class="text-center">Find Your MySQL Root Password</h3>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-warning">
                            <h5>Common MySQL Default Passwords</h5>
                            <p>Try these common passwords first:</p>
                            <ul>
                                <li><strong>Blank/Empty</strong> (no password - just press Enter)</li>
                                <li><strong>root</strong></li>
                                <li><strong>password</strong></li>
                                <li><strong>123456</strong></li>
                                <li><strong>admin</strong></li>
                            </ul>
                        </div>

                        <h4>Where to Find Your MySQL Password</h4>
                        
                        <div class="accordion" id="passwordLocation">
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#xamppLocation">
                                        XAMPP
                                    </button>
                                </h2>
                                <div id="xamppLocation" class="accordion-collapse collapse show" data-bs-parent="#passwordLocation">
                                    <div class="accordion-body">
                                        <p>XAMPP typically uses a blank password for MySQL root user by default.</p>
                                        <p>If you changed it, check:</p>
                                        <ol>
                                            <li>XAMPP Control Panel → Shell → Check if you set a password previously</li>
                                            <li>Look for any documentation or notes where you might have saved the password</li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#wampLocation">
                                        WAMP
                                    </button>
                                </h2>
                                <div id="wampLocation" class="accordion-collapse collapse" data-bs-parent="#passwordLocation">
                                    <div class="accordion-body">
                                        <p>WAMP typically uses a blank password for MySQL root user by default.</p>
                                        <p>If you changed it, you might find it in:</p>
                                        <ol>
                                            <li>WAMP system tray icon → MySQL → MySQL Console (it might prompt for password)</li>
                                            <li>Check if you created any scripts or applications that use MySQL</li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#mampLocation">
                                        MAMP
                                    </button>
                                </h2>
                                <div id="mampLocation" class="accordion-collapse collapse" data-bs-parent="#passwordLocation">
                                    <div class="accordion-body">
                                        <p>MAMP typically uses "root" as the password for MySQL root user.</p>
                                        <p>If that doesn't work:</p>
                                        <ol>
                                            <li>Check MAMP documentation or preferences</li>
                                            <li>Try the password "root" (most common for MAMP)</li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <h4 class="mt-4">What to Do If You Can't Remember</h4>
                        <div class="alert alert-info">
                            <p>If you can't remember your MySQL root password, you have two options:</p>
                            <ol>
                                <li><strong>Reset the password</strong> - <a href="reset_mysql_password.php">Follow the password reset guide</a></li>
                                <li><strong>Reinstall your server software</strong> - This will set everything back to defaults</li>
                            </ol>
                            <p>For a development environment, reinstalling is often the quickest solution.</p>
                        </div>

                        <div class="text-center mt-4">
                            <a href="test_credentials.php" class="btn btn-primary">Test Password Combinations</a>
                            <a href="reset_mysql_password.php" class="btn btn-warning">Reset MySQL Password</a>
                            <a href="fix_phpmyadmin.php" class="btn btn-info">Back to phpMyAdmin Fix</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>