<?php
session_start();

// Redirect to login if not admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

// Database connection
$host = 'localhost';
$dbname = 'campus_id_portal';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get statistics
$users_count = $pdo->query("SELECT COUNT(*) as count FROM users")->fetch()['count'];
$pending_count = $pdo->query("SELECT COUNT(*) as count FROM users WHERE status = 'pending'")->fetch()['count'];
$approved_count = $pdo->query("SELECT COUNT(*) as count FROM users WHERE status = 'approved'")->fetch()['count'];

// Get recent users
$recent_users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Campus ID Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .dashboard-header {
            background: linear-gradient(135deg, #3a0ca3, #4361ee);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
        }
        .stat-card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s;
            margin-bottom: 1.5rem;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .sidebar {
            background-color: #f8f9fa;
            border-right: 1px solid #dee2e6;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            padding-top: 2rem;
        }
        .main-content {
            margin-left: 250px;
            padding: 2rem;
        }
        .nav-link {
            color: #495057;
            padding: 0.75rem 1.25rem;
            border-left: 3px solid transparent;
        }
        .nav-link:hover, .nav-link.active {
            background-color: #e9ecef;
            color: #3a0ca3;
            border-left-color: #3a0ca3;
        }
    </style>
</head>
<body>
    <div class="sidebar" style="width: 250px;">
        <div class="px-3">
            <h4 class="text-center">Admin Panel</h4>
            <div class="text-center my-4">
                <div class="bg-primary rounded-circle d-inline-flex align-items-center justify-content-center" 
                     style="width: 80px; height: 80px;">
                    <i class="bi bi-person-gear" style="font-size: 2rem; color: white;"></i>
                </div>
                <p class="mt-2 mb-0">Welcome, <?php echo $_SESSION['admin_name']; ?></p>
                <small class="text-muted">Administrator</small>
            </div>
            
            <hr>
            
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link active" href="admin_dashboard.php">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="manage_users.php">
                        <i class="bi bi-people me-2"></i> Manage Users
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="generate_ids.php">
                        <i class="bi bi-credit-card me-2"></i> ID Cards
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
    
    <div class="main-content">
        <div class="dashboard-header">
            <div class="container">
                <h1><i class="bi bi-speedometer2"></i> Admin Dashboard</h1>
                <p class="lead">Manage your campus ID portal system</p>
            </div>
        </div>
        
        <div class="container">
            <!-- Statistics Cards -->
            <div class="row">
                <div class="col-md-4">
                    <div class="stat-card bg-primary text-white p-4 text-center">
                        <i class="bi bi-people-fill" style="font-size: 2rem;"></i>
                        <h3 class="mt-2"><?php echo $users_count; ?></h3>
                        <p class="mb-0">Total Users</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card bg-warning text-dark p-4 text-center">
                        <i class="bi bi-clock-history" style="font-size: 2rem;"></i>
                        <h3 class="mt-2"><?php echo $pending_count; ?></h3>
                        <p class="mb-0">Pending Approval</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card bg-success text-white p-4 text-center">
                        <i class="bi bi-check-circle-fill" style="font-size: 2rem;"></i>
                        <h3 class="mt-2"><?php echo $approved_count; ?></h3>
                        <p class="mb-0">Approved Users</p>
                    </div>
                </div>
            </div>
            
            <!-- Recent Users -->
            <div class="card mt-4">
                <div class="card-header bg-dark text-white">
                    <h5 class="mb-0"><i class="bi bi-list-ul"></i> Recent Registrations</h5>
                </div>
                <div class="card-body">
                    <?php if (count($recent_users) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Student ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Status</th>
                                        <th>Registered</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_users as $user): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($user['student_id']); ?></td>
                                            <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                                            <td>
                                                <?php if ($user['status'] == 'approved'): ?>
                                                    <span class="badge bg-success">Approved</span>
                                                <?php elseif ($user['status'] == 'pending'): ?>
                                                    <span class="badge bg-warning">Pending</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Rejected</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-center">No users registered yet.</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="card mt-4">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="bi bi-lightning-fill"></i> Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2 d-md-flex">
                        <a href="admin/manage_users.php" class="btn btn-primary me-md-2">
                            <i class="bi bi-people"></i> Manage Users
                        </a>
                        <a href="generate_ids.php" class="btn btn-success me-md-2">
                            <i class="bi bi-credit-card"></i> Generate ID Cards
                        </a>
                        <a href="logout.php" class="btn btn-outline-danger">
                            <i class="bi bi-box-arrow-right"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>