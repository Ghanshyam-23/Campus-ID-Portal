<?php
$error_code = isset($_GET['code']) ? $_GET['code'] : '404';
$error_messages = [
    '404' => 'Page Not Found',
    '403' => 'Access Forbidden',
    '500' => 'Internal Server Error'
];
$error_message = isset($error_messages[$error_code]) ? $error_messages[$error_code] : 'Unknown Error';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error <?php echo $error_code; ?> - Campus ID Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6 text-center">
                <h1 class="display-1"><?php echo $error_code; ?></h1>
                <h2 class="display-4"><?php echo $error_message; ?></h2>
                <p class="lead">Sorry, the page you are looking for could not be found.</p>
                <a href="index.php" class="btn btn-primary">Go Home</a>
            </div>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>