<?php
session_start();
require_once 'includes/config.php';

$user_id = $_SESSION['user_id'];

$sql = "UPDATE users SET bonafide_status='pending' WHERE id=:id";

$stmt = $pdo->prepare($sql);
$stmt->bindParam(':id',$user_id);
$stmt->execute();

header("Location: dashboard.php");
?>