<?php
/**
 * Path Fixer Script
 * This script will check and fix file path issues
 */

// Check if includes directory exists
if (!is_dir('includes')) {
    die("ERROR: 'includes' directory doesn't exist. Please create it.");
}

// Check if config.php exists
if (!file_exists('includes/config.php')) {
    // Create a basic config.php
    $config_content = '<?php
// Database configuration for XAMPP (default settings)
$host = \'localhost\';
$dbname = \'campus_id_portal\';
$username = \'root\';
$password = \'\'; // Empty password for XAMPP default

// Attempt to connect to MySQL database
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed. Please check your MySQL server is running and credentials are correct.");
}

// Set timezone
date_default_timezone_set(\'UTC\');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Define base URL
$base_url = \'http://\' . $_SERVER[\'HTTP_HOST\'] . \'/campus_id_portal/\';
define(\'BASE_URL\', $base_url);

// Include functions
require_once \'functions.php\';
?>';

    file_put_contents('includes/config.php', $config_content);
    echo "Created includes/config.php<br>";
}

// Check if other required files exist
$required_files = [
    'includes/functions.php',
    'includes/header.php',
    'includes/footer.php'
];

foreach ($required_files as $file) {
    if (!file_exists($file)) {
        // Create empty files
        file_put_contents($file, "<?php\n// $file\n?>");
        echo "Created $file<br>";
    }
}

echo "<h3>Path check completed!</h3>";
echo "<p>All required files should now be in place.</p>";
echo "<p><a href='index.php'>Go to Homepage</a></p>";
?>