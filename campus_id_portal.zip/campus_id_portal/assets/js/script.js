// General JavaScript for the Campus ID Portal

document.addEventListener('DOMContentLoaded', function() {
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
    
    // Password strength indicator
    const passwordInput = document.getElementById('password');
    if (passwordInput) {
        passwordInput.addEventListener('input', checkPasswordStrength);
    }
    
    // Confirm password match
    const confirmPasswordInput = document.getElementById('confirm_password');
    if (confirmPasswordInput) {
        confirmPasswordInput.addEventListener('input', checkPasswordMatch);
    }
    
    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });
});

function checkPasswordStrength() {
    const password = document.getElementById('password').value;
    const strengthBar = document.getElementById('password-strength');
    
    if (!strengthBar) return;
    
    let strength = 0;
    let tips = "";
    
    // Check password length
    if (password.length < 6) {
        tips += "Make the password at least 6 characters. ";
    } else {
        strength += 1;
    }
    
    // Check for mixed case
    if (password.match(/[a-z]/) && password.match(/[A-Z]/)) {
        strength += 1;
    } else {
        tips += "Use both lowercase and uppercase letters. ";
    }
    
    // Check for numbers
    if (password.match(/\d/)) {
        strength += 1;
    } else {
        tips += "Include at least one number. ";
    }
    
    // Check for special characters
    if (password.match(/[^a-zA-Z\d]/)) {
        strength += 1;
    } else {
        tips += "Include at least one special character. ";
    }
    
    // Update strength bar
    let strengthClass;
    let strengthText;
    
    switch (strength) {
        case 0:
        case 1:
            strengthClass = 'bg-danger';
            strengthText = 'Weak';
            break;
        case 2:
            strengthClass = 'bg-warning';
            strengthText = 'Fair';
            break;
        case 3:
            strengthClass = 'bg-info';
            strengthText = 'Good';
            break;
        case 4:
            strengthClass = 'bg-success';
            strengthText = 'Strong';
            break;
    }
    
    strengthBar.style.width = (strength * 25) + '%';
    strengthBar.className = 'progress-bar ' + strengthClass;
    strengthBar.textContent = strengthText;
    
    // Update tips
    const tipsElement = document.getElementById('password-tips');
    if (tipsElement) {
        if (tips) {
            tipsElement.innerHTML = tips;
            tipsElement.style.display = 'block';
        } else {
            tipsElement.style.display = 'none';
        }
    }
}

function checkPasswordMatch() {
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm_password').value;
    const matchMessage = document.getElementById('password-match-message');
    
    if (!matchMessage) return;
    
    if (confirmPassword === '') {
        matchMessage.style.display = 'none';
    } else if (password === confirmPassword) {
        matchMessage.innerHTML = 'Passwords match!';
        matchMessage.className = 'text-success';
        matchMessage.style.display = 'block';
    } else {
        matchMessage.innerHTML = 'Passwords do not match!';
        matchMessage.className = 'text-danger';
        matchMessage.style.display = 'block';
    }
}

function previewImage(input) {
    const preview = document.getElementById('photo-preview');
    if (!preview) return;
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
        }
        
        reader.readAsDataURL(input.files[0]);
    }
}

// Print ID card
function printIDCard() {
    window.print();
}

// Download ID card as PDF
function downloadIDCard() {
    // This would require a PDF generation library like jsPDF
    alert('PDF download functionality would be implemented here with a library like jsPDF.');
}