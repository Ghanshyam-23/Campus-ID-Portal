<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':id', $user_id);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$id_card = null;
$sql = "SELECT * FROM id_cards WHERE user_id = :user_id AND status = 'active'";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    $id_card = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard - Campus ID Portal</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

<?php include 'includes/header.php'; ?>

<div class="container mt-5">
<div class="row">

<!-- STUDENT PROFILE -->
<div class="col-md-4">
<div class="card">
<div class="card-header">
<h5>Student Profile</h5>
</div>

<div class="card-body text-center">

<?php if ($user['photo_path']): ?>
<img src="<?php echo $user['photo_path']; ?>" class="img-fluid rounded-circle mb-3"
style="width:150px;height:150px;object-fit:cover;">
<?php else: ?>

<div class="bg-secondary rounded-circle d-flex align-items-center justify-content-center mb-3 mx-auto"
style="width:150px;height:150px;">
<span class="text-white">No Photo</span>
</div>

<?php endif; ?>

<h4><?php echo htmlspecialchars($user['full_name']); ?></h4>
<p class="text-muted"><?php echo htmlspecialchars($user['student_id']); ?></p>

<ul class="list-group list-group-flush">

<li class="list-group-item">
<strong>Course:</strong> <?php echo htmlspecialchars($user['course']); ?>
</li>

<li class="list-group-item">
<strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?>
</li>

<li class="list-group-item">
<strong>Status:</strong>

<span class="badge bg-<?php echo $user['status']=='approved'?'success':($user['status']=='pending'?'warning':'danger'); ?>">
<?php echo ucfirst($user['status']); ?>
</span>

</li>

</ul>
</div>
</div>
</div>


<!-- RIGHT SIDE -->
<div class="col-md-8">

<?php if ($user['status'] == 'pending'): ?>

<div class="alert alert-warning">
<h5>Your account is pending approval</h5>
<p>Please wait for administrator approval.</p>
</div>

<?php elseif ($user['status'] == 'rejected'): ?>

<div class="alert alert-danger">
<h5>Your account has been rejected</h5>
<p>Please contact administration.</p>
</div>

<?php else: ?>

<!-- ID CARD STATUS -->

<div class="card mb-4">
<div class="card-header">
<h5>ID Card Status</h5>
</div>

<div class="card-body">

<?php if ($id_card): ?>

<div class="alert alert-success">
<h5>Your ID Card is Active</h5>

<p>Issued on:
<?php echo date('M d, Y', strtotime($id_card['issued_date'])); ?>
</p>

<p>Expires on:
<?php echo date('M d, Y', strtotime($id_card['expiry_date'])); ?>
</p>
</div>

<a href="generate_id_card.php" class="btn btn-primary">
View ID Card
</a>

<a href="generate_id_card.php?download=1"
class="btn btn-outline-primary">
Download ID Card
</a>

<?php else: ?>

<div class="alert alert-info">
<h5>No Active ID Card</h5>
<p>Your ID card will be generated after admin approval.</p>
</div>

<?php endif; ?>

</div>
</div>


<!-- BONAFIDE CERTIFICATE -->

<div class="card mb-4">
<div class="card-header">
<h5>Bonafide Certificate</h5>
</div>

<div class="card-body">

<?php if ($user['bonafide_status'] == 'none'): ?>

<div class="alert alert-info">
You have not requested Bonafide Certificate.
</div>

<a href="request_bonafide.php"
class="btn btn-success">
Request Bonafide Certificate
</a>

<?php elseif ($user['bonafide_status'] == 'pending'): ?>

<div class="alert alert-warning">
Your Bonafide request is waiting for admin approval.
</div>

<?php elseif ($user['bonafide_status'] == 'approved'): ?>

<div class="alert alert-success">
Bonafide Certificate Approved
</div>

<a href="generate_bonafide.php"
class="btn btn-primary">
View Certificate
</a>

<a href="generate_bonafide.php?download=1"
class="btn btn-outline-primary">
Download Certificate
</a>

<?php endif; ?>

</div>
</div>


<!-- QUICK ACTIONS -->

<div class="card">
<div class="card-header">
<h5>Quick Actions</h5>
</div>

<div class="card-body">

<div class="d-grid gap-2 d-md-flex">

<a href="update_profile.php"
class="btn btn-outline-primary me-md-2">
Update Profile
</a>

<a href="change_password.php"
class="btn btn-outline-secondary me-md-2">
Change Password
</a>

<a href="logout.php"
class="btn btn-outline-danger">
Logout
</a>

</div>

</div>
</div>

<?php endif; ?>

</div>
</div>
</div>

<?php include 'includes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>